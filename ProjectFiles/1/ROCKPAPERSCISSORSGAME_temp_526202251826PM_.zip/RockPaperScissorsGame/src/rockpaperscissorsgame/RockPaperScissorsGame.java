package rockpaperscissorsgame;


import java.util.Scanner;

public class RockPaperScissorsGame {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] computerHandArrays = {"R", "P", "S"};
        String yourHand = "", computerHand = "", thisGameWinner = "";
        int myWins = 0, computerWins = 0, tie = 0;
        int index = 0;
        for (int i = 1; i <= 5; i++) {
            System.out.println("    Game No " + i+"\n");
            System.out.println("\tMenu\n\n Rock\n Paper\n Scissors" + "\n\nEnter Your Hand (R, P or S): ");
            yourHand = in.nextLine();
            yourHand = yourHand.toUpperCase().substring(0, 1);
            index = ((int) (Math.random() * 100) % 3);
            computerHand = computerHandArrays[index];
            System.out.println("You entered: " + yourHand);
            System.out.println("Computer played: " + computerHand);

            thisGameWinner = whoTheWinnerIs(yourHand, computerHand);
            System.out.println("Game "+i+" winner: "+thisGameWinner);
            if (thisGameWinner.equals("TIE")) {
                tie++;
            } else if (thisGameWinner.equals("ME")) {
                myWins++;
            } else {
                computerWins++;
            }
            System.out.println("\n\n");
        }

        if (computerWins == myWins) {
            System.out.println("Overall Draw");
        } else if (computerWins > myWins) {
            System.out.println("The Overall winner is: COMPUTER");
        } else {
            System.out.println("The Overall winner is: ME");

        }
        System.out.println(" DETAILS OF ALL GAMES");
        System.out.println("I wins: " + myWins);
        System.out.println("Computer wins: " + computerWins);
        System.out.println("Tie: " + tie);

    }

    private static String whoTheWinnerIs(String yourHand, String computerHand) {
        String theWinner = "";
        if (yourHand.equals(computerHand)) {
            theWinner = "TIE";
        } else if ("R".equals(computerHand) && "P".equals(yourHand) || "P".equals(computerHand) && "S".equals(yourHand) || "S".equals(computerHand) && "R".equals(yourHand)) {
            theWinner = "ME";
        } else {
            theWinner = "COMPUTER";
        }
        return theWinner;
    }

}
