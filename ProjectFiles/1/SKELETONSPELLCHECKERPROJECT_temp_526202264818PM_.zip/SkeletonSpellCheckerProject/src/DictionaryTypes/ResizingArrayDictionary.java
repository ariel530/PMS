package DictionaryTypes;

import java.util.ArrayList;

import DictionaryTypes.abstractClasses.ArrayTypeDictionary;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ResizingArrayDictionary extends ArrayTypeDictionary implements DictionaryInterface {

    private String[] dictionaryData;
    private int size;
    private int currentIndex;

    /**
     * This is the default constructor used to initialized array and data
     * members
     */
    public ResizingArrayDictionary() {
        //todo
        size = 5;
        currentIndex = 0;
        dictionaryData = new String[size];

    }

    /* GENERAL METHODS Hand-in 1*/
    public void CreateDictionary(String filepath) {
        //todo
        File file
                = new File(filepath);
        Scanner sc;
        try {
            sc = new Scanner(file);
            while (sc.hasNextLine()) {
                addNewWord(sc.nextLine());
            }

        } catch (FileNotFoundException ex) {
            System.err.println(ex.getMessage());
        }

    }

    /**
     * This function check either the word exists in the array or not by
     * iterating the array
     *
     * @param word the data to find
     * @return true or false on the basis of word find
     */
    public boolean isWord(String word) {
        for (int i = 0; i < currentIndex; i++) {
            if (word.compareTo(dictionaryData[i]) == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * This function add word to array if array is full or word already exists
     * then do nothing otherwise add data to array
     *
     * @param word
     */
    public void addNewWord(String word) {
        if (!isWord(word)) {
            if(isFull())
            {
                resizeToDouble();
            }
            dictionaryData[currentIndex++] = word;
        }
    }

    /**
     * This function remove word from the array first find the index of the word
     * if index not equal to -1 means word exists then check if index is 0 then
     * simply decrease the current index else swap the index with last data in
     * array
     *
     * @param word
     */
    public void removeWord(String word) {
        //todo
        int wordIndex = getWordIndexInArray(word);
        if (wordIndex != -1) {
            if (currentIndex != 1) {
                dictionaryData[wordIndex] = dictionaryData[currentIndex - 1];
            }
            currentIndex--;
        }
        if((size/4)<=currentIndex && (size/4)>5)
        {
            resizeToForth();
        }
    }

    /**
     * This function return the data in array list
     *
     * @return
     */
    public ArrayList<String> getDictionaryWords() {
        ArrayList<String> data = new ArrayList<String>();
        for (int i = 0; i < currentIndex; i++) {
            data.add(dictionaryData[i]);
        }
        return data;
    }


    /**
     * This function return the current number of elemnets in the array
     *
     * @return number of elements
     */
    public int getNumberOfElements() {
        //todo
        return currentIndex;
    }

    //My Helper Functions  
    /**
     * This function check the current index and size of array
     *
     * @return either the array is full or not
     */
    public boolean isFull() {
        return currentIndex == size;
    }

    /**
     * This function return the index of the word in array by iterating the
     * array and check where the word is
     *
     * @param word to check
     * @return the index
     */
    public int getWordIndexInArray(String word) {
        for (int i = 0; i < currentIndex; i++) {
            if (word.compareTo(dictionaryData[i]) == 0) {
                return i;
            }
        }
        return -1;
    }
    
    
    public void resizeToDouble()
    {
        size*=2;
        String []tempWords = new String[size];
        for(int i=0;i<currentIndex;i++)
        {
           tempWords[i]=dictionaryData[i];
        }
        dictionaryData=tempWords;
    }
    
     public void resizeToForth()
    {
        size/=4;
        if(size<5)
        {
            size=5;
        }
        String []tempWords = new String[size];
        for(int i=0;i<currentIndex;i++)
        {
           tempWords[i]=dictionaryData[i];
        }
        dictionaryData=tempWords;
    }

}
