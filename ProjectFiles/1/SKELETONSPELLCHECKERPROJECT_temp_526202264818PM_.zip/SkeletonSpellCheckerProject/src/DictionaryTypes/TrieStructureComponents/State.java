package DictionaryTypes.TrieStructureComponents;

import java.util.ArrayList;

public class State {

    private ArrayList<Edge> outgoingEdges = new ArrayList<>();

    private boolean isAccept;
    private String wordUpUntil;

    public State(int index, boolean accept, String word) {
       //todo
        this.isAccept = accept || index == word.length() - 1;
        this.wordUpUntil = word.substring(0, index);
    }

    public void removeLink(State s, Character ch) {
       // you don't have to use this but you can if you want to
    }

    public void addLink(State s, Character ch) {
       // you don't have to use this but you can if you want to
    }

    public ArrayList<Edge> getOutgoingEdges() {
        return outgoingEdges;
    }

    public boolean getIsAccept() {
        return isAccept;
    }

    public String getWordUpUntil() {
        return wordUpUntil;
    }

    public void setIsAccept(boolean isAccept) {
        this.isAccept = isAccept;
    }

}
