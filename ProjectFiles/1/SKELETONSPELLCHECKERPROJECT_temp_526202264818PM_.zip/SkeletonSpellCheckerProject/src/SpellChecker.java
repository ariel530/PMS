import DictionaryTypes.*;

public class SpellChecker {

    DictionaryInterface spellChecker;

    public SpellChecker(String checkerType) {
        if (checkerType.equals("Trie")) {
            spellChecker = new TrieDictionary();
        } else if (checkerType.equals("Array")) {
            spellChecker = new ArrayDictionary();
        } else if (checkerType.equals("ResizingArray")) {
            spellChecker = new ResizingArrayDictionary();
        } else {
            System.out.println("Invalid command line input, use one of: Trie, Array, or ResizingArray");
            System.exit(0);
        }
    }

    public boolean check(String word) {
        //todo
        return spellChecker.isWord(word);
    }

    public String getBestSuggestion(String wordToCheck) {
        //todo
        if(spellChecker.getDictionaryWords().size()==0)
        {
            return "";
        }
       String []data= spellChecker.getTopNSuggestions(spellChecker.getDictionaryWords(), wordToCheck, 1);
        return data[0];
    }
}
