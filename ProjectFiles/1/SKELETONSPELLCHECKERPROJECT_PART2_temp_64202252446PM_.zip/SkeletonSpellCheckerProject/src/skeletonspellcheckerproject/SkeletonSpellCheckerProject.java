/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skeletonspellcheckerproject;

import DictionaryTypes.ArrayDictionary;
import DictionaryTypes.DictionaryInterface;
import DictionaryTypes.ResizingArrayDictionary;
import DictionaryTypes.TrieDictionary;

/**
 *
 * @author SSC
 */
public class SkeletonSpellCheckerProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        {
            DictionaryInterface da = new ResizingArrayDictionary();
            da.CreateDictionary("E:\\Abdullah --- Bahrin\\Java\\Console\\Test_30-12-2020_5000\\SkeletonSpellCheckerProject\\src\\Input\\input1.txt");
            System.out.println(da.isWord("solve"));
            da.removeWord("solve");
            System.out.println(da.isWord("solve"));

            String data[] = da.getTopNSuggestions(da.getDictionaryWords(), "solve", 4);
            for (String word : data) {
                System.out.println(word);
            }
        }

        {
            DictionaryInterface da = new ArrayDictionary();
            da.CreateDictionary("E:\\Abdullah --- Bahrin\\Java\\Console\\Test_30-12-2020_5000\\SkeletonSpellCheckerProject\\src\\Input\\input1.txt");
            System.out.println(da.isWord("solve"));
            da.removeWord("solve");
            System.out.println(da.isWord("solve"));

            String data[] = da.getTopNSuggestions(da.getDictionaryWords(), "solve", 4);
            for (String word : data) {
                System.out.println(word);
            }
        }

        {
            {
                DictionaryInterface da = new TrieDictionary();
                da.CreateDictionary("E:\\Abdullah --- Bahrin\\Java\\Console\\Test_30-12-2020_5000\\SkeletonSpellCheckerProject\\src\\Input\\input1.txt");
                System.out.println(da.isWord("solve"));
                da.removeWord("solve");
                System.out.println(da.isWord("solve"));

                String data[] = da.getTopNSuggestions(da.getDictionaryWords(), "solve", 4);
                for (String word : data) {
                    System.out.println(word);
                }

            }
        }
    }

}
