package DictionaryTypes.abstractClasses;

public abstract class ArrayTypeDictionary extends Dictionary {

    /**
     * This function describe the insertion sort It iterate over the loop and
     * iterate from each index to end swap it with larger one
     *
     * @param arr the array to sort
     * @param finalIndexForSort the index till where we need to sort
     */
    public void insertionSort(String[] arr, int finalIndexForSort) {

        finalIndexForSort = arr.length > finalIndexForSort + 1 ? finalIndexForSort : arr.length - 1;
        for (int i = 1; i <= finalIndexForSort; i++) {
            String key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j].compareTo(key) > 0) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }

    public void mergeSort(String[] arr, int finalIndexForSort) {
        //todo
        finalIndexForSort = arr.length > finalIndexForSort + 1 ? finalIndexForSort : arr.length - 1;
        dividedIntoSmallChunks(arr, 0, finalIndexForSort);
    }

    
    /**
     * This function merge and sort the array
     * @param arr
     * @param left
     * @param middle
     * @param right 
     */
    void mergeChunks(String arr[], int left, int middle, int right) {
        int n1 = middle - left + 1;
        int n2 = right - middle;

        String leftSubArray[] = new String[n1];
        String rightSubArray[] = new String[n2];

        for (int i = 0; i < n1; ++i) {
            leftSubArray[i] = arr[left + i];
        }
        for (int j = 0; j < n2; ++j) {
            rightSubArray[j] = arr[middle + 1 + j];
        }

        int i = 0, j = 0;

        int k = left;
        while (i < n1 && j < n2) {
            if (leftSubArray[i].compareTo(rightSubArray[j]) <= 0) {
                arr[k] = leftSubArray[i];
                i++;
            } else {
                arr[k] = rightSubArray[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = leftSubArray[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = rightSubArray[j];
            j++;
            k++;
        }
    }

    /**
     * This function divide the array into small chunks as much as possible
     * using recursion and then pass to mergeChunks to merge and sort the chunks
     *
     * @param arr the array to sort
     * @param left  starting index
     * @param right  ending index
     */
    void dividedIntoSmallChunks(String arr[], int left, int right) {
        if (left < right) {
            int middle = left + (right - left) / 2;

            dividedIntoSmallChunks(arr, left, middle);
            dividedIntoSmallChunks(arr, middle + 1, right);

            mergeChunks(arr, left, middle, right);
        }
    }

    /**
     * The hybrid which combine the insertion sort and merge sort to sort the
     * array
     *
     * @param arr
     * @param size
     * @param finalIndexForSort
     */
    public void hybridSort(String[] arr, int size, int finalIndexForSort) {
        //todo
        size = size < 0 ? 0 : size;
        finalIndexForSort = arr.length > finalIndexForSort + 1 ? finalIndexForSort : arr.length - 1;
        if (arr.length <= size) {
            insertionSort(arr, finalIndexForSort);
        } else {
            if (size < finalIndexForSort) {
                hybridSort(arr, size, finalIndexForSort - size);
                hybridSort(arr, finalIndexForSort - size, finalIndexForSort);
             //   mergeChunks(arr, finalIndexForSort - size, mid, finalIndexForSort);
            }
        }

    }

}
