package DictionaryTypes.abstractClasses;

import java.util.ArrayList;

public abstract class Dictionary {
   /**
     * This function return the top N words that have minimum words to match
     * @param dictionaryWords
     * @param word
     * @param N
     * @return 
     */
    public String[] getTopNSuggestions(ArrayList<String> dictionaryWords, String word, int N) {
      int currentSize = dictionaryWords.size();
        String[] words = new String[currentSize];
        int[] distance = new int[currentSize];
        for (int i = 0; i < currentSize; i++) {
            words[i] = dictionaryWords.get(i);
            distance[i] = getLevenshteinDistance(dictionaryWords.get(i), word);
        }
        for (int i = 0; i < currentSize; i++) {
            for (int j = i + 1; j < currentSize - 1; j++) {
                if (distance[i] > distance[j]) {
                    int temp = distance[i];
                    distance[i] = distance[j];
                    distance[j] = temp;

                    String tempWord = words[i];
                    words[i] = words[j];
                    words[j] = tempWord;
                }
            }
        }
        if (N > currentSize) {
            return words;
        } else {
            String[] sortWords = new String[N];
            for (int i = 0; i < N; i++) {
                sortWords[i] = words[i];
            }
            return sortWords;
        }
    }



    
    
        /**
     * This function is used to find Levenshtein distance
     *
     * @param wrongWord
     * @param actualWord
     * @return the minimum number of changes required
     */
    public int getLevenshteinDistance(String wrongWord, String actualWord) {
        int[][] dp = new int[wrongWord.length() + 1][actualWord.length() + 1];
        for (int i = 0; i <= wrongWord.length(); i++) {
            for (int j = 0; j <= actualWord.length(); j++) {

                // If wrongWord is empty, all characters of
                // actualWord are inserted into wrongWord, which is of
                // the only possible method of conversion
                // with minimum operations.
                if (i == 0) {
                    dp[i][j] = j;
                } // If actualWord is empty, all characters of wrongWord
                // are removed, which is the only possible
                //  method of conversion with minimum
                //  operations.
                else if (j == 0) {
                    dp[i][j] = i;
                } else {
                    // find the minimum among three
                    // operations below
                    int numOfReplacement = wrongWord.charAt(i - 1) == actualWord.charAt(j - 1) ? 0 : 1;
                    int replaceValue = dp[i - 1][j - 1] + numOfReplacement;
                    int deleteValue = dp[i - 1][j] + 1;
                    int insertValue = dp[i][j - 1] + 1;
                    int minimumValue = replaceValue < deleteValue ? replaceValue : deleteValue;
                    minimumValue = minimumValue < insertValue ? minimumValue : insertValue;
                    dp[i][j] = minimumValue;
                }
            }
        }

        return dp[wrongWord.length()][actualWord.length()];

    }

    
}
