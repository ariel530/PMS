package DictionaryTypes.TrieStructureComponents;

public class Edge {

    private Character character;
    private State state;

    public Edge(Character ch, State s) {
        //todo
        character = ch;
        state = s;
    }

    public Character getCharacter() {
        return character;
    }

    public void setCharacter(Character character) {
        this.character = character;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    
}
