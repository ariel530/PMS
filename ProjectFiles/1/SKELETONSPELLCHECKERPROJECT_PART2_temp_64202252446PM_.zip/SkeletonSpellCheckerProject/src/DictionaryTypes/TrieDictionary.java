package DictionaryTypes;

import DictionaryTypes.TrieStructureComponents.Edge;
import DictionaryTypes.TrieStructureComponents.State;
import java.util.ArrayList;
import DictionaryTypes.abstractClasses.Dictionary;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TrieDictionary extends Dictionary implements DictionaryInterface {

    private ArrayList<String> dictionaryData = new ArrayList<String>();
    private State state = null;

    /* SPECIFIC METHODS - Hand in 2 */
    public ArrayList<Character> BFS() {
        //todo
        ArrayList<Character> characterList = new ArrayList<Character>();
        BFS(state, characterList);
        return characterList;
    }

    /**
     * This function iterate the tire and and store
     * each character in list using DFS algorithm
     * It check if state is null then return
     * else since we need to alphabetically order
     * It iterate all the edge of the states while 
     * for each character and when found then again call it
     * recursively and at the end add the node with no next state in 
     * to list
     * @param s current state
     * @param characterList arraylist storing the character
     */
    void BFS(State s, ArrayList<Character> characterList) {
        if (s == null) {
            return;
        } else {
            ArrayList<Edge> edg = s.getOutgoingEdges();
            if (edg.size() == 0) {
                return;
            } else {
                Character currentChar = 'a';
                while (currentChar <= 'z') {
                    for (Edge temp : edg) {
                        if (temp.getCharacter() == currentChar) {
                            characterList.add(currentChar);
                            BFS(temp.getState(), characterList);
                        }
                    }
                    currentChar++;
                }

            }
        }
    }

    public ArrayList<Character> DFS() {
        //todo
        ArrayList<Character> characterList = new ArrayList<Character>();
        DFS(state, characterList);
        return characterList;
    }

     /**
     * This function iterate the tire and and store
     * each character in list using BFS algorithm
     * It check if state is null then return
     * else since we need to alphabetically order
     * It iterate all the edge of the states while 
     * for each character and when found then add to the list and
     * again call it
     * recursively 
     * @param s current state
     * @param characterList arraylist storing the character
     */
    void DFS(State s, ArrayList<Character> characterList) {
        if (s == null) {
            return;
        } else {
            ArrayList<Edge> edg = s.getOutgoingEdges();
            if (edg.size() == 0) {
                return;
            } else {
                Character currentChar = 'a';
                while (currentChar <= 'z') {
                    for (Edge temp : edg) {
                        if (temp.getCharacter() == currentChar) {
                            DFS(temp.getState(), characterList);
                            characterList.add(currentChar);
                        }
                    }
                    currentChar++;
                }

            }
        }
    }


    /* GENERAL METHODS - Hand in 1*/
    public void removeWord(String word1) {
//todo
        if (isWord(word1)) {
            removeWord(state, word1, 0);
            dictionaryData.remove(word1);
        }

    }

    private boolean removeWord(State state, String word1, int index) {
        try {
            if (index >= word1.length()) {
                if (index > word1.length()) {
                    return false;
                }
                state.setIsAccept(false);
                return state.getOutgoingEdges().isEmpty();
            }
            for (Edge edge : state.getOutgoingEdges()) {
                if (edge != null && edge.getCharacter() == word1.charAt(index)) {
                    if (removeWord(edge.getState(), word1, index + 1)) {
                        if (edge.getState().getIsAccept() == false) {
                            state.getOutgoingEdges().remove(edge);
                            return true;
                        }
                    }
                    return false;
                }
            }
            return false;
        } catch (Exception ex) {
            return false;
        }
    }

    public void CreateDictionary(String filePath) {
//todo
//todo
        File file
                = new File(filePath);
        Scanner sc;
        try {
            sc = new Scanner(file);
            while (sc.hasNextLine()) {
                addNewWord(sc.nextLine());
            }

        } catch (FileNotFoundException ex) {
            System.err.println(ex.getMessage());
        }

    }

    public boolean isWord(String word) {
        //todo
        return dictionaryData.contains(word);
    }

    public void addNewWord(String word) {
        //todo
        if (state == null) {
            state = new State(0, false, "");
        }
        if (!isWord(word)) {
            dictionaryData.add(word);
            addNewWord(state, word, 0);
        }
    }

    private void addNewWord(State state, String word, int index) {
        if (index >= word.length()) {
            if (index == word.length()) {
                state.setIsAccept(true);
            }
            return;
        }
        for (Edge edge : state.getOutgoingEdges()) {
            if (edge.getCharacter() == word.charAt(index)) {
                addNewWord(edge.getState(), word, index + 1);
                return;
            }
        }
        Edge edge = new Edge(word.charAt(index), new State(index, index == word.length() - 1, word));
        state.getOutgoingEdges().add(edge);
        addNewWord(edge.getState(), word, index + 1);
    }

    public ArrayList<String> getDictionaryWords() {
        //todo
        return dictionaryData;
    }

    public int getNumberOfElements() {
        //todo
        return dictionaryData.size();
    }

}
